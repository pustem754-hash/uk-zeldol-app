# 📦 МОДУЛЬ 00: Настройка проекта

## 🎯 Цель модуля
Создать базовую структуру Next.js проекта с настройкой Supabase, Tailwind CSS и всех необходимых зависимостей.

---

## ✅ Что будет создано

1. ✅ Next.js 14 проект с App Router
2. ✅ Конфигурация Tailwind CSS с кастомной темой УК
3. ✅ Подключение Supabase клиента
4. ✅ Базовая структура папок
5. ✅ Переменные окружения
6. ✅ Конфигурация для Netlify
7. ✅ Git настройки

---

## 📋 Предварительные требования

### Установленное ПО:
- ✅ **Node.js 18+** (проверка: `node --version`)
- ✅ **npm или yarn** (проверка: `npm --version`)
- ✅ **Git** (проверка: `git --version`)
- ✅ **GitHub Desktop** (установлен)
- ✅ **Cursor AI** (установлен)

### Аккаунты:
- ✅ **GitHub** аккаунт
- ✅ **Supabase** аккаунт (https://supabase.com)
- ✅ **Netlify** аккаунт (https://netlify.com)

---

## 🚀 ШАГ 1: Создание проекта Next.js

### 1.1 Откройте терминал в Cursor AI

Нажмите `` Ctrl+` `` (Windows/Linux) или `` Cmd+` `` (Mac)

### 1.2 Создайте проект

```bash
# Создайте папку проекта
mkdir uk-zeldol-app
cd uk-zeldol-app

# Инициализируйте Next.js проект
npx create-next-app@latest . --typescript --tailwind --app --src-dir --import-alias "@/*"
```

**Ответы на вопросы:**
```
✔ Would you like to use TypeScript? Yes
✔ Would you like to use ESLint? Yes
✔ Would you like to use Tailwind CSS? Yes
✔ Would you like to use `src/` directory? Yes
✔ Would you like to use App Router? Yes
✔ Would you like to customize the default import alias? Yes (@/*)
```

### 1.3 Установите дополнительные зависимости

```bash
# Supabase клиент
npm install @supabase/supabase-js @supabase/auth-helpers-nextjs

# UI компоненты
npm install @radix-ui/react-* class-variance-authority clsx tailwind-merge lucide-react

# Формы и валидация
npm install react-hook-form zod @hookform/resolvers

# Работа с датами
npm install date-fns

# Графики
npm install recharts

# Excel экспорт
npm install exceljs

# Загрузка файлов
npm install react-dropzone

# PDF генерация
npm install jspdf jspdf-autotable

# Уведомления
npm install react-hot-toast

# HTTP клиент
npm install axios
```

---

## 🗂️ ШАГ 2: Структура папок

Создайте следующую структуру в папке `src/`:

```
src/
├── app/                          # Next.js App Router
│   ├── (auth)/                   # Группа авторизации
│   │   ├── login/
│   │   │   └── page.tsx
│   │   └── verify/
│   │       └── page.tsx
│   ├── (resident)/               # Группа для жителей
│   │   ├── dashboard/
│   │   │   └── page.tsx
│   │   ├── meters/
│   │   │   └── page.tsx
│   │   ├── payments/
│   │   │   └── page.tsx
│   │   ├── requests/
│   │   │   └── page.tsx
│   │   ├── video/
│   │   │   └── page.tsx
│   │   ├── profile/
│   │   │   └── page.tsx
│   │   └── layout.tsx            # Общий layout для жителей
│   ├── (admin)/                  # Группа для администрации
│   │   ├── admin/
│   │   │   ├── dashboard/
│   │   │   ├── users/
│   │   │   ├── requests/
│   │   │   ├── payments/
│   │   │   └── export/
│   │   └── layout.tsx            # Общий layout для админов
│   ├── api/                      # API routes
│   │   ├── auth/
│   │   │   ├── send-code/
│   │   │   │   └── route.ts
│   │   │   └── verify-code/
│   │   │       └── route.ts
│   │   ├── meters/
│   │   ├── payments/
│   │   ├── requests/
│   │   └── export/
│   ├── layout.tsx                # Root layout
│   ├── page.tsx                  # Landing page
│   └── globals.css               # Global styles
├── components/                   # React компоненты
│   ├── ui/                       # shadcn/ui компоненты
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── input.tsx
│   │   ├── dialog.tsx
│   │   └── ...
│   ├── layout/                   # Компоненты layout
│   │   ├── Header.tsx
│   │   ├── Sidebar.tsx
│   │   ├── Footer.tsx
│   │   └── MobileNav.tsx
│   ├── features/                 # Компоненты функций
│   │   ├── meters/
│   │   │   ├── MeterForm.tsx
│   │   │   └── MeterHistory.tsx
│   │   ├── payments/
│   │   │   ├── PaymentCard.tsx
│   │   │   └── ReceiptUpload.tsx
│   │   └── requests/
│   │       ├── RequestForm.tsx
│   │       └── RequestCard.tsx
│   └── shared/                   # Общие компоненты
│       ├── Logo.tsx
│       ├── LoadingSpinner.tsx
│       └── ErrorBoundary.tsx
├── lib/                          # Утилиты и хелперы
│   ├── supabase/
│   │   ├── client.ts             # Браузерный клиент
│   │   ├── server.ts             # Серверный клиент
│   │   └── types.ts              # TypeScript типы БД
│   ├── utils/
│   │   ├── cn.ts                 # classNames утилита
│   │   ├── formatters.ts         # Форматирование данных
│   │   └── validators.ts         # Zod схемы валидации
│   └── constants/
│       ├── routes.ts             # Маршруты приложения
│       └── config.ts             # Конфигурация
├── hooks/                        # Custom React hooks
│   ├── useAuth.ts
│   ├── useUser.ts
│   ├── useMeters.ts
│   └── useRequests.ts
├── types/                        # TypeScript типы
│   ├── database.types.ts         # Автогенерированные типы Supabase
│   ├── api.types.ts
│   └── app.types.ts
└── styles/                       # Дополнительные стили
    └── themes.css
```

**Для автоматического создания структуры выполните:**

```bash
# Создайте скрипт
cat > create-structure.sh << 'EOF'
#!/bin/bash

# App routes
mkdir -p src/app/\(auth\)/{login,verify}
mkdir -p src/app/\(resident\)/{dashboard,meters,payments,requests,video,profile}
mkdir -p src/app/\(admin\)/admin/{dashboard,users,requests,payments,export}
mkdir -p src/app/api/auth/{send-code,verify-code}
mkdir -p src/app/api/{meters,payments,requests,export}

# Components
mkdir -p src/components/ui
mkdir -p src/components/layout
mkdir -p src/components/features/{meters,payments,requests}
mkdir -p src/components/shared

# Lib
mkdir -p src/lib/{supabase,utils,constants}

# Hooks
mkdir -p src/hooks

# Types
mkdir -p src/types

# Styles
mkdir -p src/styles

echo "✅ Структура папок создана!"
EOF

chmod +x create-structure.sh
./create-structure.sh
```

---

## ⚙️ ШАГ 3: Настройка переменных окружения

### 3.1 Создайте `.env.example`

```bash
cat > .env.example << 'EOF'
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

# SMS Gateway (выберите один)
# SMSC.ru
SMSC_LOGIN=your_smsc_login
SMSC_PASSWORD=your_smsc_password

# или SMS.ru
SMSRU_API_KEY=your_smsru_api_key

# App Config
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_APP_NAME=УК Зелёная долина

# Video Surveillance (Телеком Летай)
TELECOM_API_URL=your_telecom_api_url
TELECOM_API_KEY=your_telecom_api_key

# Gate Control
GATE_API_URL=your_gate_api_url
GATE_API_KEY=your_gate_api_key
EOF
```

### 3.2 Создайте `.env.local` (для разработки)

```bash
cp .env.example .env.local
```

**⚠️ ВАЖНО:** Не коммитьте `.env.local` в Git! Он уже добавлен в `.gitignore`

### 3.3 Получите ключи Supabase

1. Зайдите на https://supabase.com
2. Создайте новый проект: **"uk-zeldol-app"**
3. Дождитесь создания (2-3 минуты)
4. Перейдите в **Settings → API**
5. Скопируйте:
   - `URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` → `SUPABASE_SERVICE_ROLE_KEY`
6. Вставьте в `.env.local`

---

## 🎨 ШАГ 4: Настройка Tailwind CSS

### 4.1 Обновите `tailwind.config.ts`

```typescript
import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Цветовая схема УК "Зелёная долина"
        primary: {
          50: "#f0fdf4",
          100: "#dcfce7",
          200: "#bbf7d0",
          300: "#86efac",
          400: "#4ade80",
          500: "#2D6A4F", // Основной цвет
          600: "#16a34a",
          700: "#15803d",
          800: "#166534",
          900: "#14532d",
        },
        accent: {
          DEFAULT: "#52B788",
          light: "#95D5B2",
          dark: "#40916C",
        },
        background: {
          DEFAULT: "#FFFFFF",
          secondary: "#F1FAEE",
        },
        text: {
          primary: "#1B4332",
          secondary: "#40916C",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["Montserrat", "sans-serif"],
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
```

### 4.2 Обновите `src/app/globals.css`

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 0 0% 3.9%;
    --primary: 158 62% 29%;
    --primary-foreground: 0 0% 98%;
    --accent: 158 47% 53%;
    --accent-foreground: 158 62% 12%;
  }

  * {
    @apply border-border;
  }

  body {
    @apply bg-background text-text-primary font-sans;
  }

  h1, h2, h3, h4, h5, h6 {
    @apply font-display;
  }
}

@layer components {
  .container-uk {
    @apply container mx-auto px-4 sm:px-6 lg:px-8;
  }

  .card-uk {
    @apply bg-white rounded-lg shadow-md p-6 border border-gray-100;
  }

  .btn-primary-uk {
    @apply bg-primary-500 hover:bg-primary-600 text-white font-semibold py-2 px-4 rounded-lg transition-colors;
  }

  .btn-secondary-uk {
    @apply bg-accent hover:bg-accent-dark text-white font-semibold py-2 px-4 rounded-lg transition-colors;
  }
}
```

---

## 🔗 ШАГ 5: Настройка Supabase клиента

### 5.1 Создайте `src/lib/supabase/client.ts`

```typescript
import { createBrowserClient } from '@supabase/ssr'
import { Database } from '@/types/database.types'

export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
```

### 5.2 Создайте `src/lib/supabase/server.ts`

```typescript
import { createServerClient, type CookieOptions } from '@supabase/ssr'
import { cookies } from 'next/headers'
import { Database } from '@/types/database.types'

export async function createClient() {
  const cookieStore = await cookies()

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value
        },
        set(name: string, value: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value, ...options })
          } catch (error) {
            // Ошибка при установке cookie в Server Component
          }
        },
        remove(name: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value: '', ...options })
          } catch (error) {
            // Ошибка при удалении cookie в Server Component
          }
        },
      },
    }
  )
}
```

### 5.3 Создайте `src/lib/utils/cn.ts`

```typescript
import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
```

---

## 🌐 ШАГ 6: Настройка Netlify

### 6.1 Создайте `netlify.toml`

```toml
[build]
  command = "npm run build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"

[build.environment]
  NODE_VERSION = "18"
  NPM_FLAGS = "--legacy-peer-deps"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
```

### 6.2 Установите Netlify плагин

```bash
npm install --save-dev @netlify/plugin-nextjs
```

---

## 📝 ШАГ 7: Git настройки

### 7.1 Проверьте `.gitignore`

Убедитесь что в `.gitignore` есть:

```gitignore
# dependencies
/node_modules
/.pnp
.pnp.js

# testing
/coverage

# next.js
/.next/
/out/

# production
/build

# misc
.DS_Store
*.pem

# debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# local env files
.env*.local
.env

# vercel
.vercel

# typescript
*.tsbuildinfo
next-env.d.ts
```

### 7.2 Инициализируйте Git

```bash
git init
git add .
git commit -m "🎉 Initial commit: Project setup"
```

---

## 🚀 ШАГ 8: Первый запуск

### 8.1 Запустите dev server

```bash
npm run dev
```

Откройте http://localhost:3000 в браузере

### 8.2 Проверьте что работает

- ✅ Страница загружается
- ✅ Нет ошибок в консоли
- ✅ Tailwind CSS применяется

---

## 📤 ШАГ 9: Загрузка на GitHub

### 9.1 Откройте GitHub Desktop

1. **File → Add Local Repository**
2. Выберите папку `uk-zeldol-app`
3. Нажмите **Add Repository**

### 9.2 Опубликуйте репозиторий

1. Нажмите **Publish repository**
2. Название: `uk-zeldol-app`
3. Description: "Приложение УК Зелёная долина"
4. ✅ Отметьте **Keep this code private** (если нужно)
5. Нажмите **Publish repository**

---

## 🌐 ШАГ 10: Деплой на Netlify

### 10.1 Подключите GitHub к Netlify

1. Зайдите на https://app.netlify.com
2. **Add new site → Import an existing project**
3. Выберите **GitHub**
4. Найдите репозиторий `uk-zeldol-app`
5. Нажмите **Select**

### 10.2 Настройте деплой

**Build settings:**
- Build command: `npm run build`
- Publish directory: `.next`
- Functions directory: `netlify/functions` (оставьте пустым пока)

**Environment variables:**

Добавьте все переменные из `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL = [ваш URL]
NEXT_PUBLIC_SUPABASE_ANON_KEY = [ваш ключ]
SUPABASE_SERVICE_ROLE_KEY = [ваш service role ключ]
```

### 10.3 Запустите деплой

Нажмите **Deploy site**

Через 2-3 минуты приложение будет доступно!

---

## ✅ ПРОВЕРКА УСТАНОВКИ

Убедитесь что все работает:

```bash
# Проверка версий
node --version     # должна быть 18+
npm --version      # любая версия
git --version      # любая версия

# Проверка зависимостей
npm list @supabase/supabase-js
npm list next

# Проверка структуры
ls -la src/app
ls -la src/components
ls -la src/lib

# Запуск проекта
npm run dev

# Проверка типов
npm run type-check

# Проверка линтера
npm run lint
```

---

## 🎯 РЕЗУЛЬТАТ

После выполнения всех шагов у вас будет:

✅ Готовый Next.js 14 проект с TypeScript  
✅ Настроенный Supabase клиент  
✅ Tailwind CSS с кастомной темой УК  
✅ Структура папок по модулям  
✅ Git репозиторий на GitHub  
✅ Деплой на Netlify  
✅ Переменные окружения настроены  

---

## 📚 СЛЕДУЮЩИЕ ШАГИ

Переходите к **Модулю 01: Database** для создания схемы базы данных!

---

## 🆘 ПРОБЛЕМЫ И РЕШЕНИЯ

### Ошибка: "Module not found"
```bash
rm -rf node_modules package-lock.json
npm install
```

### Ошибка: "Supabase URL is undefined"
Проверьте `.env.local` — все переменные должны быть заполнены

### Ошибка при деплое на Netlify
Проверьте что все environment variables добавлены в настройках Netlify

---

## 🔗 ПОЛЕЗНЫЕ ССЫЛКИ

- [Next.js Docs](https://nextjs.org/docs)
- [Supabase Docs](https://supabase.com/docs)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [Netlify Docs](https://docs.netlify.com)

---

**✨ Модуль 00 завершён! Переходите к созданию базы данных!**
