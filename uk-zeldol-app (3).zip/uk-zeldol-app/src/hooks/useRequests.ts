"use client";

import { useState, useEffect } from "react";

export interface Request {
  id: string;
  title: string;
  description: string;
  category: string;
  status: "new" | "in_progress" | "done" | "canceled";
  created_at: string;
  apartment_id: string;
}

export function useRequests(apartmentId?: string) {
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // TODO: Загрузить заявки из Supabase
    // fetch('/api/requests?apartment_id=' + apartmentId)
    //   .then(res => res.json())
    //   .then(data => {
    //     setRequests(data.requests);
    //     setLoading(false);
    //   });
    
    setLoading(false);
  }, [apartmentId]);

  return { requests, loading, refetch: () => {} };
}


