"use client";

import { useEffect, useState } from "react";
import { useAuth } from "./useAuth";

export interface UserProfile {
  id: string;
  phone: string;
  full_name: string | null;
  apartment_id: string | null;
}

export function useUser() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setProfile(null);
      setLoading(false);
      return;
    }

    // TODO: Загрузить профиль из Supabase
    // const fetchProfile = async () => {
    //   const { data } = await supabase
    //     .from('profiles')
    //     .select('*')
    //     .eq('id', user.id)
    //     .single();
    //   setProfile(data);
    //   setLoading(false);
    // };
    // fetchProfile();

    setLoading(false);
  }, [user]);

  return { profile, loading };
}


