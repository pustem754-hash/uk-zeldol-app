"use client";

import { useState, useEffect } from "react";

export interface Meter {
  id: string;
  type: "electricity" | "water_cold" | "water_hot" | "gas";
  name: string;
  unit: string;
  last_reading: number | null;
  last_reading_date: string | null;
}

export function useMeters(apartmentId?: string) {
  const [meters, setMeters] = useState<Meter[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // TODO: Загрузить счётчики из Supabase
    // fetch('/api/meters?apartment_id=' + apartmentId)
    //   .then(res => res.json())
    //   .then(data => {
    //     setMeters(data.meters);
    //     setLoading(false);
    //   });
    
    setLoading(false);
  }, [apartmentId]);

  return { meters, loading };
}


