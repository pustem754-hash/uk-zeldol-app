// Типы для API запросов и ответов

export interface ApiResponse<T> {
  data?: T;
  error?: {
    message: string;
    code?: string;
  };
  success: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
}

// Типы для аутентификации
export interface SendCodeRequest {
  phone: string;
}

export interface VerifyCodeRequest {
  phone: string;
  code: string;
}

export interface VerifyCodeResponse {
  session: {
    access_token: string;
    refresh_token: string;
    user: {
      id: string;
      phone: string;
    };
  };
}

// Типы для счетчиков
export interface MeterReading {
  id: string;
  apartment_id: string;
  service_type: "water" | "electricity" | "gas";
  reading: number;
  reading_date: string;
  photo_url?: string;
  created_at: string;
}

export interface SubmitMeterReadingRequest {
  apartment_id: string;
  service_type: "water" | "electricity" | "gas";
  reading: number;
  reading_date: string;
  photo?: File;
}

// Типы для платежей
export interface Payment {
  id: string;
  apartment_id: string;
  period: string; // YYYY-MM
  total_amount: number;
  paid_amount: number;
  status: "paid" | "partial" | "unpaid";
  receipt_url?: string;
  created_at: string;
}

export interface PaymentHistory {
  payment_date: string;
  amount: number;
  method: string;
  receipt_url?: string;
}

// Типы для заявок
export interface ServiceRequest {
  id: string;
  apartment_id: string;
  category: string;
  description: string;
  status: "new" | "work" | "done" | "cancel";
  photos?: string[];
  created_at: string;
  updated_at: string;
}

export interface CreateRequestRequest {
  apartment_id: string;
  category: string;
  description: string;
  photos?: File[];
}

// Типы для экспорта
export interface ExportOptions {
  format: "excel" | "pdf";
  dateFrom?: string;
  dateTo?: string;
  apartmentIds?: string[];
}


