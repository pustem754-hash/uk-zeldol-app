// Типы для приложения

export type ResidentialComplex = "northern" | "southern";

export interface User {
  id: string;
  phone: string;
  full_name?: string;
  email?: string;
  residential_complex_id?: string;
  created_at: string;
}

export interface Apartment {
  id: string;
  building_id: string;
  number: string;
  area: number;
  floor: number;
  rooms: number;
  owner_id: string;
  services: Service[];
}

export interface Service {
  id: string;
  name: string;
  type: "utility" | "housing" | "additional";
  unit: string;
  tariff: number;
}

export interface Building {
  id: string;
  residential_complex_id: string;
  address: string;
  floors: number;
  apartments: Apartment[];
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  read: boolean;
  created_at: string;
}

export interface MeterService {
  type: "water" | "electricity" | "gas";
  name: string;
  unit: string;
  lastReading?: number;
  lastReadingDate?: string;
}

// Типы для форм
export interface FormError {
  field: string;
  message: string;
}

export interface FormState<T> {
  data: T;
  errors: FormError[];
  loading: boolean;
}

// Типы для таблиц
export interface TableColumn<T> {
  key: keyof T | string;
  label: string;
  sortable?: boolean;
  render?: (value: any, row: T) => React.ReactNode;
}

export interface TableProps<T> {
  data: T[];
  columns: TableColumn<T>[];
  loading?: boolean;
  onRowClick?: (row: T) => void;
}

// Типы для графиков
export interface ChartData {
  name: string;
  value: number;
  date?: string;
}

// Типы для фильтров
export interface DateRange {
  from: Date;
  to: Date;
}

export interface FilterOptions {
  dateRange?: DateRange;
  status?: string[];
  category?: string[];
  apartmentIds?: string[];
}


