export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      residential_complexes: {
        Row: {
          id: string;
          name: string;
          address: string;
          management_company: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          address: string;
          management_company: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          address?: string;
          management_company?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      // Добавьте остальные таблицы из SQL скриптов
      buildings: {
        Row: {
          id: string;
          residential_complex_id: string;
          address: string;
          floors: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          residential_complex_id: string;
          address: string;
          floors: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          residential_complex_id?: string;
          address?: string;
          floors?: number;
          created_at?: string;
        };
      };
      // Пока упрощенная структура, полную добавлю после выполнения SQL
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
  };
}


