export const ROUTES = {
  home: "/",
  login: "/login",
  verify: "/verify",
  dashboard: "/dashboard",
  meters: "/meters",
  payments: "/payments",
  requests: "/requests",
  video: "/video",
  profile: "/profile",
  admin: "/admin",
} as const;

export type Route = typeof ROUTES[keyof typeof ROUTES];










