export const APP_CONFIG = {
  name: process.env.NEXT_PUBLIC_APP_NAME || "УК Зелёная долина",
  url: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
  managementCompany: "ООО 'Управляющая Компания Зелёная долина'",
  address: "422550, РТ, г. Зеленодольск, ул. Шустова, 4А, пом. 15",
  phone: "+7 960 072 03 21",
  email: "uk-zeldol@yandex.ru",
  director: "Галлямов Руслан Рафисович",
} as const;

export const RESIDENTIAL_COMPLEXES = {
  MAYAK: {
    name: "ЖК 'Маяк'",
    buildings: 2,
    apartments: 175,
  },
  ZELENAYA_DOLINA: {
    name: "ЖК 'Зелёная долина'",
    buildings: 4,
    apartments: 489,
  },
} as const;

export const SMS_CONFIG = {
  codeLength: 4,
  codeExpiration: 5 * 60 * 1000, // 5 минут
  maxAttempts: 3,
  rateLimit: 60 * 1000, // 1 минута
} as const;











