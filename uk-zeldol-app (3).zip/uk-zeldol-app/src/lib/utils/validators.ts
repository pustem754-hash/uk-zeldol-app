import { z } from "zod";

export const phoneSchema = z
  .string()
  .regex(/^\+7\s?\(?[0-9]{3}\)?\s?[0-9]{3}-?[0-9]{2}-?[0-9]{2}$/, {
    message: "Неверный формат телефона",
  });

export const meterReadingSchema = z.object({
  meter_id: z.string().uuid(),
  reading: z.number().min(0, { message: "Показание не может быть отрицательным" }),
  photo_url: z.string().url().optional(),
  submitted_at: z.string().datetime(),
});

export const paymentSchema = z.object({
  charge_id: z.string().uuid(),
  receipt_url: z.string().url().optional(),
  payment_date: z.string().datetime(),
  amount: z.number().min(0),
});

export const requestSchema = z.object({
  title: z.string().min(3, { message: "Минимум 3 символа" }).max(200),
  description: z.string().min(10).max(1000),
  category: z.enum(["plumbing", "electrical", "elevator", "cleaning", "other"]),
  apartment_id: z.string().uuid(),
});
















