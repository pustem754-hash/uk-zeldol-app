export function formatPhone(phone: string): string {
  // Убираем все кроме цифр
  const cleaned = phone.replace(/\D/g, "");

  // Форматируем как +7 (XXX) XXX-XX-XX
  if (cleaned.length === 11 && cleaned.startsWith("7")) {
    return `+7 (${cleaned.substring(1, 4)}) ${cleaned.substring(4, 7)}-${cleaned.substring(7, 9)}-${cleaned.substring(9, 11)}`;
  }

  // Если не стандартный формат, просто добавляем +
  if (cleaned.startsWith("8") && cleaned.length === 11) {
    return `+7${cleaned.substring(1)}`;
  }

  return phone;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
  }).format(amount);
}

export function formatDate(date: Date | string): string {
  return new Intl.DateTimeFormat("ru-RU", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(date));
}

export function formatDateTime(date: Date | string): string {
  return new Intl.DateTimeFormat("ru-RU", {
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(date));
}











