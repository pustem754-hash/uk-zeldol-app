import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  // TODO: Получить заявки из Supabase
  return NextResponse.json({ requests: [] });
}

export async function POST(request: NextRequest) {
  // TODO: Создать заявку в Supabase
  return NextResponse.json({ success: true });
}


