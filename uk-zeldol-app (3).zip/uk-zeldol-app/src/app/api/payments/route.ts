import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  // TODO: Получить платежи из Supabase
  return NextResponse.json({ payments: [] });
}


