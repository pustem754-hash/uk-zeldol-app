import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-accent-light">
      <div className="container-uk py-16">
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-primary-800 mb-4">
            Добро пожаловать в УК "Зелёная долина"
          </h1>
          <p className="text-xl text-text-secondary max-w-2xl mx-auto">
            Современный сервис для жителей ЖК "Маяк" и "Зелёная долина"
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <Card>
            <CardHeader>
              <CardTitle>🔋 Показания счетчиков</CardTitle>
              <CardDescription>
                Подавайте показания счетчиков воды, электричества и газа онлайн
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/meters">
                <Button variant="outline" className="w-full">
                  Перейти
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>💳 Квитанции и оплата</CardTitle>
              <CardDescription>
                Просмотр начислений, скачивание квитанций и загрузка чеков
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/payments">
                <Button variant="outline" className="w-full">
                  Перейти
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>🛠️ Заявки на ремонт</CardTitle>
              <CardDescription>
                Создавайте заявки на устранение неполадок и следите за статусом
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/requests">
                <Button variant="outline" className="w-full">
                  Перейти
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>📹 Видеонаблюдение</CardTitle>
              <CardDescription>
                Просмотр камер видеонаблюдения в реальном времени
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/video">
                <Button variant="outline" className="w-full">
                  Перейти
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>🚪 Управление шлагбаумом</CardTitle>
              <CardDescription>
                Открытие ворот и шлагбаума прямо из приложения
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" className="w-full" disabled>
                Скоро
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>👤 Мой профиль</CardTitle>
              <CardDescription>
                Управление лицевыми счетами и личными данными
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/profile">
                <Button variant="outline" className="w-full">
                  Перейти
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <p className="text-text-secondary mb-4">
            📱 Скачайте мобильное приложение для iOS и Android
          </p>
          <div className="flex gap-4 justify-center">
            <Button variant="secondary" size="lg">
              📱 App Store
            </Button>
            <Button variant="secondary" size="lg">
              🤖 Google Play
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}











