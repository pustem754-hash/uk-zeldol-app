"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatDateTime } from "@/lib/utils/formatters";

interface RequestCardProps {
  id: string;
  title: string;
  description: string;
  category: string;
  status: "new" | "in_progress" | "done" | "canceled";
  createdAt: string;
}

export default function RequestCard({
  id,
  title,
  description,
  category,
  status,
  createdAt,
}: RequestCardProps) {
  const statusColors = {
    new: "bg-blue-100 text-blue-800",
    in_progress: "bg-yellow-100 text-yellow-800",
    done: "bg-green-100 text-green-800",
    canceled: "bg-red-100 text-red-800",
  };

  const statusLabels = {
    new: "Новая",
    in_progress: "В работе",
    done: "Выполнено",
    canceled: "Отменено",
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Заявка #{id}</span>
          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${statusColors[status]}`}>
            {statusLabels[status]}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="font-semibold mb-2">{title}</p>
        <p className="text-gray-600 text-sm mb-4">{description}</p>
        <div className="flex justify-between text-sm text-gray-500">
          <span>Категория: {category}</span>
          <span>{formatDateTime(createdAt)}</span>
        </div>
      </CardContent>
    </Card>
  );
}


