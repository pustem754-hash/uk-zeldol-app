"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function RequestForm() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("plumbing");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Отправить заявку
    console.log({ title, description, category });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Новая заявка</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block mb-2">Категория</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2 border rounded-lg"
            >
              <option value="plumbing">Водоснабжение</option>
              <option value="electrical">Электроснабжение</option>
              <option value="elevator">Лифт</option>
              <option value="cleaning">Уборка</option>
              <option value="other">Другое</option>
            </select>
          </div>
          <div>
            <label className="block mb-2">Описание проблемы</label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Краткое описание"
            />
          </div>
          <div>
            <label className="block mb-2">Подробности</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2 border rounded-lg min-h-[100px]"
              placeholder="Детальное описание проблемы..."
            />
          </div>
          <Button type="submit" className="w-full">
            Отправить заявку
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}


