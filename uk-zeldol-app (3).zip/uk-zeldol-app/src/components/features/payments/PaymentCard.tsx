"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils/formatters";

interface PaymentCardProps {
  id: string;
  period: string;
  amount: number;
  status: "paid" | "pending" | "overdue";
  onPay?: () => void;
}

export default function PaymentCard({
  id,
  period,
  amount,
  status,
  onPay,
}: PaymentCardProps) {
  const statusColors = {
    paid: "bg-green-100 text-green-800",
    pending: "bg-yellow-100 text-yellow-800",
    overdue: "bg-red-100 text-red-800",
  };

  const statusLabels = {
    paid: "Оплачено",
    pending: "Ожидает оплаты",
    overdue: "Просрочено",
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>Период: {period}</span>
          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${statusColors[status]}`}>
            {statusLabels[status]}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <span className="text-2xl font-bold">{formatCurrency(amount)}</span>
        </div>
        {status !== "paid" && (
          <Button onClick={onPay} className="w-full">
            Оплатить
          </Button>
        )}
      </CardContent>
    </Card>
  );
}


