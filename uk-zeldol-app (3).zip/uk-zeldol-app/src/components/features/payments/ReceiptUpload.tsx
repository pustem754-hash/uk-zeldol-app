"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function ReceiptUpload() {
  const [file, setFile] = useState<File | null>(null);

  const handleUpload = async () => {
    if (!file) return;
    // TODO: Загрузить чек в Supabase Storage
    console.log("Uploading receipt:", file.name);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Загрузить чек об оплате</CardTitle>
      </CardHeader>
      <CardContent>
        <input
          type="file"
          accept="image/*,application/pdf"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
          className="mb-4"
        />
        <Button onClick={handleUpload} disabled={!file}>
          Загрузить
        </Button>
      </CardContent>
    </Card>
  );
}


