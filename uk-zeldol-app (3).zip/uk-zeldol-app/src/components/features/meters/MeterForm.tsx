"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function MeterForm() {
  const [readings, setReadings] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Отправить показания
    console.log("Submitting readings:", readings);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Показания счётчиков</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* TODO: Динамически загрузить счётчики */}
          <div>
            <label className="block mb-2">Электроэнергия (кВт·ч)</label>
            <Input
              type="number"
              placeholder="Введите показание"
              value={readings.electricity || ""}
              onChange={(e) =>
                setReadings({ ...readings, electricity: e.target.value })
              }
            />
          </div>
          <Button type="submit" className="w-full">
            Отправить показания
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}


