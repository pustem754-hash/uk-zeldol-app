"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function MeterHistory() {
  // TODO: Загрузить историю показаний
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>История показаний</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-500">История пока пуста</p>
      </CardContent>
    </Card>
  );
}


