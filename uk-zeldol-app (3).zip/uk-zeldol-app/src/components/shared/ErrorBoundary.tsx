"use client";

import { Component, ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Error caught by boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="container-uk py-16 text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">
            Что-то пошло не так
          </h1>
          <p className="text-gray-600 mb-8">
            {this.state.error?.message || "Произошла ошибка"}
          </p>
          <button
            onClick={() => this.setState({ hasError: false })}
            className="btn-primary-uk"
          >
            Попробовать снова
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}


