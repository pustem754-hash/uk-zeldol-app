import Image from "next/image";
import Link from "next/link";

interface LogoProps {
  size?: number;
  showText?: boolean;
}

export default function Logo({ size = 50, showText = true }: LogoProps) {
  return (
    <Link href="/" className="flex items-center gap-3">
      <Image
        src="/logo-original.png"
        alt="УК Зелёная Долина"
        width={size}
        height={size}
        className="object-contain"
      />
      {showText && (
        <span className="font-bold text-primary-700 text-lg">
          УК "Зелёная Долина"
        </span>
      )}
    </Link>
  );
}


