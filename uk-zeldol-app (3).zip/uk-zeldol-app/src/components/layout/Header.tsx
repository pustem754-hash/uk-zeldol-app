import Link from "next/link";
import Image from "next/image";

export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b">
      <div className="container-uk">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-3">
            <Image
              src="/logo-original.png"
              alt="УК Зелёная Долина"
              width={40}
              height={40}
              className="object-contain"
            />
            <span className="font-bold text-primary-700">
              УК "Зелёная Долина"
            </span>
          </Link>
          <nav className="flex gap-4">
            {/* TODO: Добавить навигацию */}
          </nav>
        </div>
      </div>
    </header>
  );
}


