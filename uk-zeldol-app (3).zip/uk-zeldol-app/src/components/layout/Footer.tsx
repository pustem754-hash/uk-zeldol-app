import { APP_CONFIG } from "@/lib/constants/config";

export default function Footer() {
  return (
    <footer className="bg-primary-800 text-white mt-auto">
      <div className="container-uk py-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-bold mb-4">{APP_CONFIG.name}</h3>
            <p className="text-sm text-primary-200">
              {APP_CONFIG.address}
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Контакты</h4>
            <p className="text-sm text-primary-200">
              📞 {APP_CONFIG.phone}
            </p>
            <p className="text-sm text-primary-200">
              ✉️ {APP_CONFIG.email}
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Директор</h4>
            <p className="text-sm text-primary-200">
              {APP_CONFIG.director}
            </p>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-primary-700 text-center text-sm text-primary-300">
          © {new Date().getFullYear()} {APP_CONFIG.managementCompany}
        </div>
      </div>
    </footer>
  );
}


