"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

export default function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();

  const menuItems = [
    { href: "/dashboard", label: "Дашборд", icon: "📊" },
    { href: "/meters", label: "Счётчики", icon: "🔋" },
    { href: "/payments", label: "Платежи", icon: "💳" },
    { href: "/requests", label: "Заявки", icon: "🛠️" },
    { href: "/video", label: "Видео", icon: "📹" },
    { href: "/profile", label: "Профиль", icon: "👤" },
  ];

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden fixed bottom-4 right-4 z-50 bg-primary-600 text-white p-4 rounded-full shadow-lg"
      >
        {isOpen ? "✕" : "☰"}
      </button>
      {isOpen && (
        <nav className="md:hidden fixed bottom-20 right-4 z-40 bg-white rounded-lg shadow-xl p-4 min-w-[200px]">
          <div className="space-y-2">
            {menuItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setIsOpen(false)}
                className={`flex items-center gap-3 px-4 py-2 rounded-lg ${
                  pathname === item.href
                    ? "bg-primary-100 text-primary-700"
                    : "text-gray-700"
                }`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </div>
        </nav>
      )}
    </>
  );
}


