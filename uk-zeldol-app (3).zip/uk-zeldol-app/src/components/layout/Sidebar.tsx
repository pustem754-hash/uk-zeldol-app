"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export default function Sidebar() {
  const pathname = usePathname();

  const menuItems = [
    { href: "/dashboard", label: "📊 Дашборд", icon: "📊" },
    { href: "/meters", label: "🔋 Счётчики", icon: "🔋" },
    { href: "/payments", label: "💳 Платежи", icon: "💳" },
    { href: "/requests", label: "🛠️ Заявки", icon: "🛠️" },
    { href: "/video", label: "📹 Видео", icon: "📹" },
    { href: "/profile", label: "👤 Профиль", icon: "👤" },
  ];

  return (
    <aside className="w-64 bg-white border-r min-h-screen p-4">
      <nav className="space-y-2">
        {menuItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
              pathname === item.href
                ? "bg-primary-100 text-primary-700 font-semibold"
                : "text-gray-700 hover:bg-gray-100"
            }`}
          >
            <span>{item.icon}</span>
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
    </aside>
  );
}


