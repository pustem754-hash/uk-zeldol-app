-- ================================================
-- МОДУЛЬ 01: Структура недвижимости
-- ================================================

-- Жилые комплексы
CREATE TABLE residential_complexes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  address TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Дома
CREATE TABLE buildings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  complex_id UUID REFERENCES residential_complexes(id) ON DELETE CASCADE,
  address TEXT NOT NULL UNIQUE,
  total_apartments INTEGER DEFAULT 0,
  total_storage_units INTEGER DEFAULT 0,
  floors INTEGER,
  entrances INTEGER,
  year_built INTEGER,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Квартиры и кладовые
CREATE TABLE apartments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  building_id UUID NOT NULL REFERENCES buildings(id) ON DELETE CASCADE,
  apartment_number TEXT NOT NULL,
  type apartment_type NOT NULL DEFAULT 'apartment',
  floor INTEGER,
  entrance INTEGER,
  area NUMERIC(10, 2),
  rooms INTEGER,
  residents_count INTEGER DEFAULT 0,
  account_number TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(building_id, apartment_number, type)
);

-- Индексы
CREATE INDEX idx_buildings_complex ON buildings(complex_id);
CREATE INDEX idx_apartments_building ON apartments(building_id);
CREATE INDEX idx_apartments_account ON apartments(account_number);
CREATE INDEX idx_apartments_type ON apartments(type);

-- Комментарии
COMMENT ON TABLE residential_complexes IS 'Жилые комплексы';
COMMENT ON TABLE buildings IS 'Дома в ЖК';
COMMENT ON TABLE apartments IS 'Квартиры и кладовые помещения';

COMMENT ON COLUMN apartments.type IS 'apartment = квартира, storage = кладовка';
COMMENT ON COLUMN apartments.account_number IS 'Лицевой счет (уникальный)';

-- Триггер обновления updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_complexes_updated_at BEFORE UPDATE ON residential_complexes
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_buildings_updated_at BEFORE UPDATE ON buildings
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_apartments_updated_at BEFORE UPDATE ON apartments
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DO $$
BEGIN
  RAISE NOTICE '✅ Таблицы недвижимости созданы!';
END $$;
