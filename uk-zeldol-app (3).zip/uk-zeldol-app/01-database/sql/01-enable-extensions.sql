-- ================================================
-- МОДУЛЬ 01: Включение расширений PostgreSQL
-- ================================================

-- UUID генерация
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Полнотекстовый поиск
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Работа с JSON
CREATE EXTENSION IF NOT EXISTS "btree_gin";

-- ================================================
-- СОЗДАНИЕ ENUM ТИПОВ
-- ================================================

-- Типы недвижимости
CREATE TYPE apartment_type AS ENUM ('apartment', 'storage');

-- Роли пользователей
CREATE TYPE user_role AS ENUM (
  'resident',      -- Житель
  'dispatcher',    -- Диспетчер
  'executor',      -- Исполнитель
  'manager',       -- Руководство
  'admin'          -- Администратор
);

-- Типы счетчиков
CREATE TYPE meter_type AS ENUM (
  'cold_water',    -- ХВС
  'hot_water',     -- ГВС
  'electricity',   -- Электричество
  'gas'            -- Газ
);

-- Статусы показаний
CREATE TYPE reading_status AS ENUM ('pending', 'approved', 'rejected');

-- Типы услуг
CREATE TYPE service_type AS ENUM (
  'cold_water',
  'hot_water',
  'electricity',
  'gas',
  'heating',
  'maintenance',
  'garbage',
  'internet',
  'tv',
  'security'
);

-- Статусы начислений
CREATE TYPE charge_status AS ENUM ('unpaid', 'pending', 'paid', 'overdue');

-- Статусы платежей
CREATE TYPE payment_status AS ENUM ('pending', 'approved', 'rejected');

-- Приоритеты заявок
CREATE TYPE request_priority AS ENUM ('low', 'medium', 'high', 'urgent');

-- Статусы заявок
CREATE TYPE request_status AS ENUM (
  'new',           -- Новая
  'assigned',      -- Назначена
  'in_progress',   -- В работе
  'completed',     -- Выполнена
  'cancelled'      -- Отменена
);

-- Типы вложений
CREATE TYPE attachment_type AS ENUM ('photo', 'video', 'audio', 'document');

-- Типы уведомлений
CREATE TYPE notification_type AS ENUM ('info', 'warning', 'success', 'error');

-- Категории документов
CREATE TYPE document_category AS ENUM (
  'contract',      -- Договор
  'act',           -- Акт
  'protocol',      -- Протокол
  'certificate',   -- Справка
  'regulation',    -- Положение
  'other'          -- Другое
);

-- ================================================
-- КОММЕНТАРИИ
-- ================================================

COMMENT ON EXTENSION "uuid-ossp" IS 'Генерация UUID';
COMMENT ON EXTENSION "pg_trgm" IS 'Полнотекстовый поиск с триграммами';

COMMENT ON TYPE user_role IS 'Роли пользователей в системе';
COMMENT ON TYPE meter_type IS 'Типы приборов учета';
COMMENT ON TYPE request_status IS 'Статусы заявок жителей';

-- ================================================
-- УСПЕХ
-- ================================================

DO $$
BEGIN
  RAISE NOTICE '✅ Расширения и типы успешно созданы!';
END $$;
