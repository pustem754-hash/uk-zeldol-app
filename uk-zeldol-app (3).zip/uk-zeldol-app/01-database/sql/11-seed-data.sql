-- ================================================
-- МОДУЛЬ 01: Первоначальные данные
-- ================================================

-- Жилые комплексы
INSERT INTO residential_complexes (name, address) VALUES
('ЖК "Маяк"', 'г. Зеленодольск, ул. Рогачёва, д. 25'),
('ЖК "Зелёная долина"', 'г. Зеленодольск, мкр. Зелёная Долина');

-- Дома ЖК "Маяк"
INSERT INTO buildings (complex_id, address, total_apartments, floors) 
SELECT 
  (SELECT id FROM residential_complexes WHERE name = 'ЖК "Маяк"'),
  'ул. Рогачёва, д. 25, корп. 1',
  105,
  10
UNION ALL
SELECT 
  (SELECT id FROM residential_complexes WHERE name = 'ЖК "Маяк"'),
  'ул. Рогачёва, д. 25, корп. 2',
  70,
  9;

-- Дома ЖК "Зелёная долина"
INSERT INTO buildings (complex_id, address, total_apartments, floors)
SELECT 
  (SELECT id FROM residential_complexes WHERE name = 'ЖК "Зелёная долина"'),
  'мкр. Зелёная Долина, д. 1',
  67,
  9
UNION ALL
SELECT 
  (SELECT id FROM residential_complexes WHERE name = 'ЖК "Зелёная долина"'),
  'мкр. Зелёная Долина, д. 3',
  220,
  16
UNION ALL
SELECT 
  (SELECT id FROM residential_complexes WHERE name = 'ЖК "Зелёная долина"'),
  'мкр. Зелёная Долина, д. 5, с. Айша',
  141,
  12
UNION ALL
SELECT 
  (SELECT id FROM residential_complexes WHERE name = 'ЖК "Зелёная долина"'),
  'мкр. Зелёная Долина, д. 7, с. Айша',
  61,
  7;

-- Категории заявок
INSERT INTO request_categories (name, icon, color) VALUES
('Сантехника', 'droplet', '#3B82F6'),
('Электрика', 'zap', '#F59E0B'),
('Общедомовое имущество', 'building', '#10B981'),
('Лифт', 'arrow-up-down', '#8B5CF6'),
('Отопление', 'flame', '#EF4444'),
('Уборка', 'sparkles', '#06B6D4'),
('Другое', 'alert-circle', '#6B7280');

-- Тарифы (примерные на 2025 год)
INSERT INTO tariffs (service_type, price_per_unit, unit, valid_from) VALUES
('cold_water', 35.50, 'м³', '2025-01-01'),
('hot_water', 145.80, 'м³', '2025-01-01'),
('electricity', 4.85, 'кВт·ч', '2025-01-01'),
('gas', 6.20, 'м³', '2025-01-01'),
('heating', 2250.00, 'Гкал', '2025-01-01'),
('maintenance', 25.00, 'м²', '2025-01-01');

DO $$
BEGIN
  RAISE NOTICE '✅ Начальные данные загружены!';
  RAISE NOTICE 'Добавлено:';
  RAISE NOTICE '  - 2 жилых комплекса';
  RAISE NOTICE '  - 6 домов';
  RAISE NOTICE '  - 7 категорий заявок';
  RAISE NOTICE '  - 6 тарифов';
END $$;
