# 🗄️ МОДУЛЬ 01: База данных

## 🎯 Цель модуля
Создать полную схему PostgreSQL базы данных в Supabase для всех функций приложения УК.

---

## 📊 АРХИТЕКТУРА БАЗЫ ДАННЫХ

### Основные сущности:

1. **Пользователи и авторизация**
   - `users` — пользователи системы (Supabase Auth)
   - `profiles` — профили пользователей
   - `sms_codes` — коды для авторизации

2. **Недвижимость**
   - `residential_complexes` — жилые комплексы
   - `buildings` — дома
   - `apartments` — квартиры и кладовые
   - `resident_accounts` — привязка жителей к ЛС

3. **Счетчики и показания**
   - `meters` — приборы учета
   - `meter_readings` — показания счетчиков
   - `tariffs` — тарифы на услуги

4. **Платежи**
   - `charges` — начисления (квитанции)
   - `charge_details` — детализация начислений
   - `payments` — платежи и чеки

5. **Заявки (Requests)**
   - `request_categories` — категории заявок
   - `requests` — заявки жителей
   - `request_statuses` — история статусов
   - `request_messages` — чат по заявке
   - `request_attachments` — вложения

6. **Уведомления**
   - `notifications` — уведомления для жителей
   - `news` — новости УК

7. **Видеонаблюдение и контроль доступа**
   - `cameras` — камеры видеонаблюдения
   - `gates` — шлагбаумы/ворота
   - `gate_logs` — логи открытий

8. **Документы**
   - `documents` — документы УК

---

## 🚀 ШАГ 1: Создание таблиц

### 1.1 Зайдите в Supabase

1. Откройте https://supabase.com/dashboard
2. Выберите проект `uk-zeldol-app`
3. Перейдите в **SQL Editor**

### 1.2 Выполните SQL скрипты

Скопируйте и выполните каждый скрипт по порядку из папки `sql/`:

1. `01-enable-extensions.sql` — включение расширений
2. `02-residential-structure.sql` — структура недвижимости
3. `03-profiles-auth.sql` — профили и авторизация
4. `04-meters.sql` — счетчики
5. `05-payments.sql` — платежи
6. `06-requests.sql` — заявки
7. `07-notifications.sql` — уведомления
8. `08-surveillance.sql` — видеонаблюдение
9. `09-documents.sql` — документы
10. `10-rls-policies.sql` — Row Level Security

---

## 📝 ДЕТАЛЬНЫЕ SQL СКРИПТЫ

Все SQL файлы находятся в папке `01-database/sql/`

### Краткое описание таблиц:

#### 🏘️ Недвижимость

**residential_complexes** — Жилые комплексы
```sql
- id (uuid)
- name (text) — "ЖК Маяк", "ЖК Зелёная долина"
- address (text)
- created_at
```

**buildings** — Дома
```sql
- id (uuid)
- complex_id (uuid) → residential_complexes
- address (text) — "ул. Рогачёва, д. 25, корп. 1"
- total_apartments (integer)
- floors (integer)
- created_at
```

**apartments** — Квартиры и кладовые
```sql
- id (uuid)
- building_id (uuid) → buildings
- apartment_number (text) — "25"
- type (enum) — 'apartment', 'storage'
- area (numeric) — площадь
- rooms (integer)
- residents_count (integer)
- account_number (text) — лицевой счет
- created_at
```

**resident_accounts** — Привязка жителей к ЛС
```sql
- id (uuid)
- user_id (uuid) → auth.users
- apartment_id (uuid) → apartments
- is_owner (boolean) — собственник или жилец
- created_at
```

#### 👤 Профили и авторизация

**profiles** — Профили пользователей
```sql
- id (uuid) → auth.users
- phone (text) — +79600720321
- full_name (text)
- email (text)
- role (enum) — 'resident', 'dispatcher', 'executor', 'manager', 'admin'
- is_debtor (boolean) — должник
- debt_amount (numeric)
- avatar_url (text)
- created_at
- updated_at
```

**sms_codes** — SMS коды для входа
```sql
- id (uuid)
- phone (text)
- code (text) — 4-значный код
- expires_at (timestamp)
- verified (boolean)
- created_at
```

#### 🔋 Счетчики

**meters** — Приборы учета
```sql
- id (uuid)
- apartment_id (uuid) → apartments
- type (enum) — 'cold_water', 'hot_water', 'electricity', 'gas'
- serial_number (text)
- installation_date (date)
- next_verification_date (date)
- is_active (boolean)
- created_at
```

**meter_readings** — Показания
```sql
- id (uuid)
- meter_id (uuid) → meters
- apartment_id (uuid) → apartments
- previous_value (numeric)
- current_value (numeric)
- consumption (numeric) — авторасчет
- photo_url (text) — фото счетчика
- submitted_by (uuid) → profiles
- submitted_at (timestamp)
- status (enum) — 'pending', 'approved', 'rejected'
- verified_by (uuid) → profiles
- notes (text)
- created_at
```

**tariffs** — Тарифы
```sql
- id (uuid)
- service_type (enum) — 'cold_water', 'hot_water', 'electricity', 'gas', 'maintenance'
- price_per_unit (numeric)
- unit (text) — "м³", "кВт·ч"
- valid_from (date)
- valid_to (date)
- created_at
```

#### 💳 Платежи

**charges** — Начисления (квитанции)
```sql
- id (uuid)
- apartment_id (uuid) → apartments
- period_month (integer)
- period_year (integer)
- total_amount (numeric)
- status (enum) — 'unpaid', 'pending', 'paid', 'overdue'
- due_date (date)
- pdf_url (text) — ссылка на PDF квитанцию
- created_at
```

**charge_details** — Детализация начислений
```sql
- id (uuid)
- charge_id (uuid) → charges
- service_type (enum)
- consumption (numeric)
- tariff (numeric)
- amount (numeric)
- notes (text)
```

**payments** — Платежи
```sql
- id (uuid)
- charge_id (uuid) → charges
- apartment_id (uuid) → apartments
- amount (numeric)
- receipt_image_url (text) — скриншот чека
- uploaded_by (uuid) → profiles
- uploaded_at (timestamp)
- status (enum) — 'pending', 'approved', 'rejected'
- verified_by (uuid) → profiles
- verified_at (timestamp)
- comment (text)
- created_at
```

#### 🛠️ Заявки

**request_categories** — Категории
```sql
- id (uuid)
- name (text) — "Сантехника", "Электрика"
- icon (text) — название иконки
- color (text) — цвет категории
- created_at
```

**requests** — Заявки
```sql
- id (uuid)
- apartment_id (uuid) → apartments
- created_by (uuid) → profiles
- category_id (uuid) → request_categories
- title (text)
- description (text)
- priority (enum) — 'low', 'medium', 'high', 'urgent'
- status (enum) — 'new', 'assigned', 'in_progress', 'completed', 'cancelled'
- assigned_to (uuid) → profiles (исполнитель)
- assigned_by (uuid) → profiles (диспетчер)
- completed_at (timestamp)
- rating (integer) — оценка от 1 до 5
- rating_comment (text)
- created_at
- updated_at
```

**request_statuses** — История статусов
```sql
- id (uuid)
- request_id (uuid) → requests
- status (enum)
- changed_by (uuid) → profiles
- comment (text)
- created_at
```

**request_messages** — Чат по заявке
```sql
- id (uuid)
- request_id (uuid) → requests
- sender_id (uuid) → profiles
- message (text)
- created_at
```

**request_attachments** — Вложения
```sql
- id (uuid)
- request_id (uuid) → requests
- type (enum) — 'photo', 'video', 'audio', 'document'
- file_url (text)
- uploaded_by (uuid) → profiles
- is_completion_photo (boolean) — фотоотчет
- created_at
```

#### 📢 Уведомления

**notifications** — Уведомления
```sql
- id (uuid)
- user_id (uuid) → profiles
- title (text)
- message (text)
- type (enum) — 'info', 'warning', 'success', 'error'
- link (text) — ссылка для перехода
- is_read (boolean)
- created_at
```

**news** — Новости УК
```sql
- id (uuid)
- title (text)
- content (text)
- image_url (text)
- published_at (timestamp)
- is_pinned (boolean)
- created_by (uuid) → profiles
```

#### 📹 Видеонаблюдение

**cameras** — Камеры
```sql
- id (uuid)
- building_id (uuid) → buildings
- name (text) — "Подъезд 1", "Парковка"
- location (text)
- stream_url (text) — RTSP/HLS ссылка
- is_active (boolean)
- created_at
```

**gates** — Шлагбаумы
```sql
- id (uuid)
- building_id (uuid) → buildings
- name (text) — "Главный въезд"
- control_url (text) — API для открытия
- api_key (text)
- is_active (boolean)
- created_at
```

**gate_logs** — Логи открытий
```sql
- id (uuid)
- gate_id (uuid) → gates
- opened_by (uuid) → profiles
- apartment_id (uuid) → apartments
- opened_at (timestamp)
```

#### 📄 Документы

**documents** — Документы УК
```sql
- id (uuid)
- title (text)
- description (text)
- category (enum) — 'contract', 'act', 'protocol', 'certificate'
- file_url (text)
- uploaded_by (uuid) → profiles
- is_public (boolean) — доступен всем жителям
- created_at
```

---

## 🔐 ШАГ 2: Row Level Security (RLS)

RLS обеспечивает что:
- Жители видят только свои данные
- Диспетчеры и администраторы видят всё
- Запросы автоматически фильтруются

Все политики безопасности находятся в `10-rls-policies.sql`

**Примеры политик:**

```sql
-- Жители видят только свои квартиры
CREATE POLICY "residents_view_own_apartments"
ON apartments FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT apartment_id 
    FROM resident_accounts 
    WHERE user_id = auth.uid()
  )
);

-- Жители видят только свои показания
CREATE POLICY "residents_view_own_readings"
ON meter_readings FOR SELECT
TO authenticated
USING (
  apartment_id IN (
    SELECT apartment_id 
    FROM resident_accounts 
    WHERE user_id = auth.uid()
  )
);
```

---

## 📊 ШАГ 3: Первоначальные данные

### 3.1 Жилые комплексы и дома

Выполните `11-seed-data.sql` для добавления:

- 2 ЖК (Маяк, Зелёная долина)
- 6 домов с адресами
- 664 квартиры
- Базовые категории заявок
- Тарифы на услуги

### 3.2 Тестовые пользователи (опционально)

Создайте тестовых пользователей для разработки в `12-test-users.sql`

---

## 🔄 ШАГ 4: Функции и триггеры

### 4.1 Автоматический расчет потребления

```sql
CREATE OR REPLACE FUNCTION calculate_consumption()
RETURNS TRIGGER AS $$
BEGIN
  NEW.consumption = NEW.current_value - NEW.previous_value;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER calculate_consumption_trigger
BEFORE INSERT OR UPDATE ON meter_readings
FOR EACH ROW
EXECUTE FUNCTION calculate_consumption();
```

### 4.2 Автоматическое обновление статуса должника

```sql
CREATE OR REPLACE FUNCTION update_debtor_status()
RETURNS void AS $$
BEGIN
  UPDATE profiles p
  SET 
    is_debtor = (
      SELECT SUM(c.total_amount) > 0
      FROM charges c
      JOIN resident_accounts ra ON c.apartment_id = ra.apartment_id
      WHERE ra.user_id = p.id
        AND c.status IN ('unpaid', 'overdue')
    ),
    debt_amount = (
      SELECT COALESCE(SUM(c.total_amount), 0)
      FROM charges c
      JOIN resident_accounts ra ON c.apartment_id = ra.apartment_id
      WHERE ra.user_id = p.id
        AND c.status IN ('unpaid', 'overdue')
    );
END;
$$ LANGUAGE plpgsql;
```

---

## 📥 ШАГ 5: Экспорт типов для TypeScript

### 5.1 Установите Supabase CLI

```bash
npm install -g supabase
```

### 5.2 Сгенерируйте типы

```bash
npx supabase gen types typescript --project-id your_project_id > src/types/database.types.ts
```

### 5.3 Используйте типы в коде

```typescript
import { Database } from '@/types/database.types'

type Apartment = Database['public']['Tables']['apartments']['Row']
type MeterReading = Database['public']['Tables']['meter_readings']['Insert']
```

---

## ✅ ПРОВЕРКА УСТАНОВКИ

Выполните проверочные запросы в SQL Editor:

```sql
-- Проверка структуры
SELECT tablename FROM pg_tables 
WHERE schemaname = 'public' 
ORDER BY tablename;

-- Проверка данных
SELECT * FROM residential_complexes;
SELECT * FROM buildings;
SELECT COUNT(*) FROM apartments;

-- Проверка RLS политик
SELECT tablename, policyname 
FROM pg_policies 
WHERE schemaname = 'public';
```

---

## 🎯 РЕЗУЛЬТАТ

После выполнения модуля у вас будет:

✅ Полная схема БД с 20+ таблицами  
✅ Row Level Security настроен  
✅ Триггеры для автоматизации  
✅ Первоначальные данные загружены  
✅ TypeScript типы сгенерированы  

---

## 📚 СЛЕДУЮЩИЕ ШАГИ

Переходите к **Модулю 02: Auth SMS** для создания авторизации через телефон!

---

## 🆘 ПРОБЛЕМЫ И РЕШЕНИЯ

### Ошибка: "permission denied for schema public"
Проверьте что вы используете правильный проект в Supabase

### Ошибка: "relation already exists"
Таблица уже создана. Можно пропустить или удалить: `DROP TABLE IF EXISTS table_name CASCADE;`

### Ошибка при генерации типов
Убедитесь что Supabase CLI установлен и project_id правильный

---

**✨ Модуль 01 завершён! База данных готова к использованию!**
